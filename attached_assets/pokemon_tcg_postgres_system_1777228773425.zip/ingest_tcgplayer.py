import requests

def fetch_tcgplayer(key, product_id):
    url = f"https://api.tcgplayer.com/pricing/product/{product_id}"
    headers = {"Authorization": f"Bearer {key}"}
    r = requests.get(url, headers=headers)

    if r.status_code == 200:
        return r.json()
    return None
