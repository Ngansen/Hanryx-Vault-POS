from ebaysdk.finding import Connection

def fetch_ebay(app_id, query):
    api = Connection(appid=app_id, config_file=None)
    res = api.execute("findCompletedItems", {
        "keywords": query,
        "itemFilter": [{"name": "SoldItemsOnly", "value": True}]
    })

    items = res.dict().get("searchResult", {}).get("item", [])
    out = []

    for i in items:
        try:
            out.append({
                "price": float(i["sellingStatus"]["currentPrice"]["value"])
            })
        except:
            pass

    return out
