# Pokémon TCG Postgres Pricing System

Full offline + live marketplace integration engine.

## Features
- PostgreSQL schema
- eBay / TCGplayer / Cardmarket ingestion (templates)
- Multi-language card system
- Variant handling
- Pricing engine
- Grading valuation system

## Setup
1. Install requirements
2. Create Postgres DB
3. Run schema.sql
4. Configure API keys in config.json
5. Run sync.py
