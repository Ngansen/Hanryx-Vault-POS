CREATE TABLE cards (
  global_id TEXT PRIMARY KEY,
  pokedex INT,
  hp INT,
  types TEXT[],
  supertype TEXT
);

CREATE TABLE localizations (
  id SERIAL PRIMARY KEY,
  global_id TEXT,
  lang TEXT,
  name TEXT,
  flavor_text TEXT
);

CREATE TABLE variants (
  variant_id TEXT PRIMARY KEY,
  global_id TEXT,
  lang TEXT,
  set_id TEXT,
  number TEXT,
  rarity TEXT,
  image TEXT
);

CREATE TABLE price_latest (
  variant_id TEXT PRIMARY KEY,
  avg_raw FLOAT,
  avg_psa10 FLOAT,
  avg_cgc10 FLOAT,
  avg_bgs10 FLOAT,
  avg_tag10 FLOAT,
  updated TIMESTAMP
);
