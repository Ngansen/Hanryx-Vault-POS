def average(prices):
    return sum(prices)/len(prices) if prices else 0

def compute_price(ebay, tcg, cm):
    all_prices = []

    if ebay:
        all_prices += [p['price'] for p in ebay]

    if tcg:
        all_prices.append(tcg)

    if cm:
        all_prices += cm if isinstance(cm, list) else [cm]

    return average(all_prices)
