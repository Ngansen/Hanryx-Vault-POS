GRADING_MULTIPLIERS = {
  "PSA": {10: 12, 9: 3, 8: 1.5},
  "CGC": {10: 10, 9.5: 4, 9: 2},
  "BGS": {10: 15, 9.5: 5, 9: 2.5},
  "TAG": {10: 11, 9: 3.5, 8: 1.6}
}

def apply_grade(base, company, grade):
    return base * GRADING_MULTIPLIERS.get(company, {}).get(grade, 1)
