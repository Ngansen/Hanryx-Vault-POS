import psycopg2
import time
from pricing_engine import compute_price

def sync_loop(conn, variants, ebay, tcg, cm):
    cur = conn.cursor()

    while True:
        for v in variants:
            price = compute_price(ebay(v), tcg(v), cm(v))

            cur.execute("""
                INSERT INTO price_latest VALUES (%s,%s,%s,%s,%s,%s,NOW())
                ON CONFLICT (variant_id)
                DO UPDATE SET avg_raw=%s, updated=NOW()
            """, (v, price, price, price, price, price, price))

        conn.commit()
        time.sleep(3600)
