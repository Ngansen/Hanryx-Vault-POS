import requests
from bs4 import BeautifulSoup

def fetch_cardmarket(query):
    url = f"https://www.cardmarket.com/en/Pokemon/Products/Search?searchString={query}"
    r = requests.get(url)
    soup = BeautifulSoup(r.text, "html.parser")

    prices = []
    for p in soup.select(".price-container"):
        try:
            prices.append(float(p.text.replace('€','').strip()))
        except:
            pass

    return prices
